- [x] Analisar o site de subliminares fornecido
- [x] Planejar a estrutura e o conteúdo do novo site
- [x] Desenvolver o site
- [x] Fazer deploy do site e entregar o link

